export interface Meal {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  emoji: string;
  time: string;
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  image?: string;
  note?: string;
}

export interface Activity {
  id: string;
  type: string;
  emoji: string;
  duration: number;
  caloriesBurned: number;
  time: string;
  note?: string;
  location?: string;
}

export interface DayLog {
  date: string;
  meals: Meal[];
  activities: Activity[];
  water: number;
  weight?: number;
  weeklyGoal?: string;
  mood?: string;
  notes?: string;
}

export interface UserProfile {
  targets: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  weeklyGoal: string;
  currentStreak: number;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  text: string;
  image?: string;
  timestamp: string;
}
