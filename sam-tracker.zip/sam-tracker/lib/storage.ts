import { DayLog, UserProfile } from './types';

const TODAY = () => new Date().toISOString().split('T')[0];

export function getProfile(): UserProfile {
  if (typeof window === 'undefined') return defaultProfile();
  const raw = localStorage.getItem('sam_profile');
  return raw ? JSON.parse(raw) : defaultProfile();
}

export function saveProfile(p: UserProfile) {
  localStorage.setItem('sam_profile', JSON.stringify(p));
}

export function getDayLog(date?: string): DayLog {
  const d = date || TODAY();
  if (typeof window === 'undefined') return emptyDay(d);
  const raw = localStorage.getItem(`sam_day_${d}`);
  return raw ? JSON.parse(raw) : emptyDay(d);
}

export function saveDayLog(log: DayLog) {
  localStorage.setItem(`sam_day_${log.date}`, JSON.stringify(log));
}

export function getLast7Days(): DayLog[] {
  const days: DayLog[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().split('T')[0];
    const raw = typeof window !== 'undefined' ? localStorage.getItem(`sam_day_${key}`) : null;
    days.push(raw ? JSON.parse(raw) : emptyDay(key));
  }
  return days;
}

function defaultProfile(): UserProfile {
  return {
    targets: { calories: 1400, protein: 125, carbs: 120, fat: 48 },
    weeklyGoal: 'Lose fat, heal neck, stay consistent 💪',
    currentStreak: 3,
  };
}

function emptyDay(date: string): DayLog {
  return { date, meals: [], activities: [], water: 0 };
}
