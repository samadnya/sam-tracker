'use client';
import { useState } from 'react';
import { Activity } from '@/lib/types';
import { Plus, MapPin, Dumbbell, Footprints, Music2, Bike, Plane, X } from 'lucide-react';

const QUICK_ACTIVITIES = [
  { type: 'Walk', emoji: '🚶', icon: Footprints, kcalPerMin: 4, color: '#60C8F0' },
  { type: 'Dance cardio', emoji: '💃', icon: Music2, kcalPerMin: 7, color: '#FF87AB' },
  { type: 'Strength training', emoji: '🏋️', icon: Dumbbell, kcalPerMin: 6, color: '#A78BFA' },
  { type: 'Cycling', emoji: '🚴', icon: Bike, kcalPerMin: 8, color: '#00D4A0' },
  { type: 'Travel day', emoji: '✈️', icon: Plane, kcalPerMin: 2, color: '#FFB347' },
  { type: 'Custom', emoji: '⚡', icon: Plus, kcalPerMin: 5, color: '#8a7a9a' },
];

interface Props {
  activities: Activity[];
  onAdd: (a: Activity) => void;
  onDelete: (id: string) => void;
}

export default function ActivityLogger({ activities, onAdd, onDelete }: Props) {
  const [adding, setAdding] = useState(false);
  const [selected, setSelected] = useState(QUICK_ACTIVITIES[0]);
  const [duration, setDuration] = useState(30);
  const [location, setLocation] = useState('');
  const [customType, setCustomType] = useState('');
  const [customEmoji, setCustomEmoji] = useState('⚡');

  const totalBurned = activities.reduce((s, a) => s + a.caloriesBurned, 0);

  const log = () => {
    const isCustom = selected.type === 'Custom';
    const type = isCustom ? customType || 'Activity' : selected.type;
    const emoji = isCustom ? customEmoji : selected.emoji;
    const burned = Math.round(selected.kcalPerMin * duration);
    const activity: Activity = {
      id: Date.now().toString(),
      type, emoji, duration, caloriesBurned: burned,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      location: location || undefined,
    };
    onAdd(activity);
    setAdding(false);
    setLocation('');
    setCustomType('');
    setDuration(30);
  };

  return (
    <div className="card mb-3">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 800, color: '#1a1a2e' }}>Movement & Activity</div>
          {totalBurned > 0 && (
            <div style={{ fontSize: 11, color: '#00D4A0', fontWeight: 700, marginTop: 2 }}>
              🔥 {totalBurned} kcal burned today
            </div>
          )}
        </div>
        <button onClick={() => setAdding(!adding)} style={{
          background: adding ? '#f5f5f5' : 'linear-gradient(135deg,#A78BFA,#60C8F0)',
          border: 'none', borderRadius: 10, padding: '6px 12px', cursor: 'pointer',
          fontSize: 12, fontWeight: 800, color: adding ? '#8a7a9a' : 'white',
          display: 'flex', alignItems: 'center', gap: 4
        }}>
          {adding ? <><X size={12} /> Cancel</> : <><Plus size={12} /> Log</>}
        </button>
      </div>

      {/* Logged activities */}
      {activities.length === 0 && !adding && (
        <div style={{ textAlign: 'center', padding: '12px 0', color: '#c0b0d0', fontSize: 12, fontWeight: 600 }}>
          No movement logged yet — tap Log to add! 🏃
        </div>
      )}
      {activities.map(a => (
        <div key={a.id} style={{
          display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0',
          borderBottom: '1px solid #f0e8f4'
        }}>
          <div style={{ width: 34, height: 34, borderRadius: 10, background: '#F0E8FF', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>{a.emoji}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#1a1a2e' }}>
              {a.type} {a.location && <span style={{ color: '#A78BFA' }}>· {a.location}</span>}
            </div>
            <div style={{ fontSize: 11, color: '#8a7a9a', marginTop: 1 }}>
              {a.time} · {a.duration} min · −{a.caloriesBurned} kcal
            </div>
          </div>
          <button onClick={() => onDelete(a.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#ddd', fontSize: 16, padding: '0 2px' }}>×</button>
        </div>
      ))}

      {/* Add form */}
      {adding && (
        <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid #f0e8f4' }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: '#8a7a9a', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Activity type</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 12 }}>
            {QUICK_ACTIVITIES.map(act => (
              <button key={act.type} onClick={() => setSelected(act)} style={{
                padding: '8px 10px', borderRadius: 10,
                border: selected.type === act.type ? `2px solid ${act.color}` : '1px solid #f0e0f0',
                background: selected.type === act.type ? `${act.color}18` : 'white',
                cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, fontWeight: 700,
                color: selected.type === act.type ? '#1a1a2e' : '#8a7a9a'
              }}>
                <span style={{ fontSize: 14 }}>{act.emoji}</span> {act.type}
              </button>
            ))}
          </div>

          {selected.type === 'Custom' && (
            <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
              <input value={customEmoji} onChange={e => setCustomEmoji(e.target.value)} placeholder="🏊" style={{
                width: 48, padding: '8px', borderRadius: 10, border: '1px solid #f0e0f0',
                fontSize: 18, textAlign: 'center', outline: 'none'
              }} />
              <input value={customType} onChange={e => setCustomType(e.target.value)} placeholder="e.g. Swimming, Yoga, Hiking..." style={{
                flex: 1, padding: '8px 12px', borderRadius: 10, border: '1px solid #f0e0f0',
                fontSize: 13, fontWeight: 600, outline: 'none'
              }} />
            </div>
          )}

          <div style={{ marginBottom: 10 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontSize: 11, fontWeight: 800, color: '#8a7a9a', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Duration</span>
              <span style={{ fontSize: 13, fontWeight: 800, color: '#A78BFA' }}>{duration} min · ~{Math.round(selected.kcalPerMin * duration)} kcal</span>
            </div>
            <input type="range" min={5} max={120} step={5} value={duration} onChange={e => setDuration(Number(e.target.value))}
              style={{ width: '100%', accentColor: '#A78BFA' }} />
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: '#c0b0d0', marginTop: 2 }}>
              <span>5 min</span><span>2 hours</span>
            </div>
          </div>

          <input value={location} onChange={e => setLocation(e.target.value)} placeholder="📍 Location / city (optional)" style={{
            width: '100%', padding: '8px 12px', borderRadius: 10, border: '1px solid #f0e0f0',
            fontSize: 13, fontWeight: 600, outline: 'none', marginBottom: 10
          }} />

          <button onClick={log} style={{
            width: '100%', padding: '12px', borderRadius: 12, border: 'none',
            background: 'linear-gradient(135deg,#A78BFA,#60C8F0)',
            color: 'white', fontWeight: 800, fontSize: 14, cursor: 'pointer'
          }}>
            Log {selected.emoji} {selected.type === 'Custom' ? customType || 'Activity' : selected.type}
          </button>
        </div>
      )}
    </div>
  );
}
