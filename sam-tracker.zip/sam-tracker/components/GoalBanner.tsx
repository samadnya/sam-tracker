'use client';
import { useState } from 'react';
import { Pencil, Check, X } from 'lucide-react';

interface Props {
  goal: string;
  onSave: (g: string) => void;
}

const QUICK_GOALS = [
  'Lose fat, heal neck 💪',
  'Cardio week — legs & abs 🦵',
  'Maintenance — travel week ✈️',
  'High protein focus 🥩',
  'Active recovery week 🧘',
  'Back to strength training 🏋️',
];

export default function GoalBanner({ goal, onSave }: Props) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(goal);

  const save = () => { onSave(draft); setEditing(false); };
  const cancel = () => { setDraft(goal); setEditing(false); };

  if (editing) return (
    <div className="card mb-3" style={{ border: '2px solid #FF87AB' }}>
      <div style={{ fontSize: 11, fontWeight: 800, color: '#FF87AB', marginBottom: 8, letterSpacing: '0.05em', textTransform: 'uppercase' }}>
        ✏️ Edit your weekly goal
      </div>
      <textarea
        value={draft}
        onChange={e => setDraft(e.target.value)}
        rows={2}
        style={{
          width: '100%', border: '1px solid #FFD6E7', borderRadius: 10,
          padding: '8px 10px', fontSize: 13, fontWeight: 600, color: '#1a1a2e',
          background: '#FFF9FB', outline: 'none', resize: 'none', marginBottom: 8
        }}
      />
      <div style={{ fontSize: 11, fontWeight: 700, color: '#8a7a9a', marginBottom: 8 }}>Quick pick:</div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 10 }}>
        {QUICK_GOALS.map(g => (
          <button key={g} onClick={() => setDraft(g)} style={{
            padding: '4px 10px', borderRadius: 99, border: '1px solid #FFD6E7',
            background: draft === g ? '#FFD6E7' : 'white', fontSize: 11, fontWeight: 700,
            color: '#c0395e', cursor: 'pointer'
          }}>{g}</button>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <button onClick={save} style={{
          flex: 1, padding: '8px', borderRadius: 10, border: 'none',
          background: 'linear-gradient(135deg,#FF87AB,#FFB347)', color: 'white',
          fontWeight: 800, fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4
        }}><Check size={14} /> Save goal</button>
        <button onClick={cancel} style={{
          padding: '8px 14px', borderRadius: 10, border: '1px solid #eee',
          background: 'white', fontWeight: 700, fontSize: 13, cursor: 'pointer', color: '#8a7a9a'
        }}><X size={14} /></button>
      </div>
    </div>
  );

  return (
    <div className="gradient-peach card mb-3" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
      <div>
        <div style={{ fontSize: 10, fontWeight: 800, color: '#b06a00', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 3 }}>
          🎯 This week's goal
        </div>
        <div style={{ fontSize: 13, fontWeight: 700, color: '#3a2a1e' }}>{goal}</div>
      </div>
      <button onClick={() => setEditing(true)} style={{
        background: 'rgba(255,255,255,0.6)', border: 'none', borderRadius: 8,
        padding: '6px 8px', cursor: 'pointer', flexShrink: 0
      }}>
        <Pencil size={14} color="#b06a00" />
      </button>
    </div>
  );
}
