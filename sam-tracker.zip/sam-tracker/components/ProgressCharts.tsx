'use client';
import { DayLog } from '@/lib/types';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Legend
} from 'recharts';

interface Props { logs: DayLog[]; targets: { calories: number; protein: number } }

const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export default function ProgressCharts({ logs, targets }: Props) {
  const data = logs.map((log, i) => {
    const eaten = log.meals.reduce((s, m) => s + m.calories, 0);
    const burned = log.activities.reduce((s, a) => s + a.caloriesBurned, 0);
    const protein = log.meals.reduce((s, m) => s + m.protein, 0);
    const label = new Date(log.date + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short' });
    return { day: label, calories: eaten, burned, net: Math.max(0, eaten - burned), protein, weight: log.weight };
  });

  const weightData = data.filter(d => d.weight);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.length) return null;
    return (
      <div style={{ background: 'white', border: '1px solid #f0e0f4', borderRadius: 10, padding: '8px 12px', fontSize: 12, fontWeight: 700 }}>
        <div style={{ color: '#8a7a9a', marginBottom: 4 }}>{label}</div>
        {payload.map((p: any) => (
          <div key={p.name} style={{ color: p.color }}>{p.name}: {p.value}{p.name.includes('kg') ? 'kg' : p.name.includes('kcal') || p.name.includes('cal') ? ' kcal' : 'g'}</div>
        ))}
      </div>
    );
  };

  const hasData = data.some(d => d.calories > 0);

  return (
    <div>
      {/* Calorie vs Burned */}
      <div className="card mb-3">
        <div style={{ fontSize: 13, fontWeight: 800, color: '#1a1a2e', marginBottom: 4 }}>Calories in vs burned 🔥</div>
        <div style={{ fontSize: 11, color: '#FF87AB', fontWeight: 700, marginBottom: 12 }}>
          {hasData ? "You're consistently close to target — incredible discipline! 🎯" : "Start logging meals to see your trends!"}
        </div>
        {!hasData ? (
          <div style={{ textAlign: 'center', padding: '40px 0', color: '#c0b0d0', fontSize: 13, fontWeight: 600 }}>No data yet this week 🌱</div>
        ) : (
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={data} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f5eef8" />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#8a7a9a', fontFamily: 'Nunito' }} />
              <YAxis tick={{ fontSize: 10, fill: '#8a7a9a', fontFamily: 'Nunito' }} domain={[0, 1800]} />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine y={targets.calories} stroke="#FF87AB" strokeDasharray="5 4" strokeWidth={2} />
              <Bar dataKey="calories" name="Eaten kcal" fill="#FFD6E7" radius={[4,4,0,0]} />
              <Bar dataKey="burned" name="Burned kcal" fill="#A78BFA" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
        <div style={{ display: 'flex', gap: 14, marginTop: 8, flexWrap: 'wrap' }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: '#8a7a9a', fontWeight: 600 }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: '#FFD6E7', display: 'inline-block' }}></span>Eaten
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: '#8a7a9a', fontWeight: 600 }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: '#A78BFA', display: 'inline-block' }}></span>Burned
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: '#FF87AB', fontWeight: 600 }}>
            <span style={{ width: 24, height: 2, background: '#FF87AB', display: 'inline-block', borderRadius: 1 }}></span>Target
          </span>
        </div>
      </div>

      {/* Protein */}
      <div className="card mb-3">
        <div style={{ fontSize: 13, fontWeight: 800, color: '#1a1a2e', marginBottom: 4 }}>Daily protein (g) 🥩</div>
        <div style={{ fontSize: 11, color: '#A78BFA', fontWeight: 700, marginBottom: 12 }}>
          {hasData ? "Bars above the line = muscles protected! 💜" : "Hit your protein goal each day to keep that muscle!"}
        </div>
        {!hasData ? (
          <div style={{ textAlign: 'center', padding: '40px 0', color: '#c0b0d0', fontSize: 13, fontWeight: 600 }}>No data yet 🌱</div>
        ) : (
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={data} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f5eef8" />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#8a7a9a', fontFamily: 'Nunito' }} />
              <YAxis tick={{ fontSize: 10, fill: '#8a7a9a', fontFamily: 'Nunito' }} domain={[0, 160]} />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine y={targets.protein} stroke="#FF87AB" strokeDasharray="5 4" strokeWidth={2} />
              <Bar dataKey="protein" name="Protein g" fill="#E8D5FF" radius={[4,4,0,0]}
                label={false} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Weight */}
      <div className="card mb-3">
        <div style={{ fontSize: 13, fontWeight: 800, color: '#1a1a2e', marginBottom: 4 }}>Weight trend (kg) ⚖️</div>
        <div style={{ fontSize: 11, color: '#00D4A0', fontWeight: 700, marginBottom: 12 }}>
          {weightData.length > 1 ? "Every decimal down is a win! You're doing it! 🌟" : "Log your weight daily to track progress!"}
        </div>
        {weightData.length < 2 ? (
          <div style={{ textAlign: 'center', padding: '40px 0', color: '#c0b0d0', fontSize: 13, fontWeight: 600 }}>
            Log weight in Today tab to see trend 📉
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={160}>
            <LineChart data={data.filter(d => d.weight)} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f5eef8" />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#8a7a9a', fontFamily: 'Nunito' }} />
              <YAxis tick={{ fontSize: 10, fill: '#8a7a9a', fontFamily: 'Nunito' }} domain={['dataMin - 0.5', 'dataMax + 0.5']} />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="weight" name="Weight kg" stroke="#00D4A0" strokeWidth={2.5} dot={{ r: 4, fill: '#00D4A0' }} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
