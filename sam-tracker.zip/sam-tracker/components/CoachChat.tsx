'use client';
import { useState, useRef, useEffect } from 'react';
import { Send, Camera, X } from 'lucide-react';
import { ChatMessage, Meal, Activity } from '@/lib/types';

interface Props {
  totals: { calories: number; protein: number; carbs: number; fat: number };
  targets: { calories: number; protein: number; carbs: number; fat: number };
  weeklyGoal: string;
  activities: Activity[];
  onMealLogged: (m: Meal) => void;
  onActivityLogged: (a: Activity) => void;
}

const AFFIRMATIONS = [
  "You're building the body AND the life, one meal at a time 💕",
  "Consistency > perfection. You're absolutely nailing it! ⭐",
  "Your discipline is genuinely inspiring — keep going! 🔥",
  "Every good choice compounds. You're glowing! ✨",
];

export default function CoachChat({ totals, targets, weeklyGoal, activities, onMealLogged, onActivityLogged }: Props) {
  const [history, setHistory] = useState<ChatMessage[]>([{
    role: 'assistant',
    text: `Hey! 👋 I'm your daily coach. Snap a photo of any meal, describe what you ate, or tell me about your workout — I'll log it and cheer you on! 🎯\n\n${AFFIRMATIONS[Math.floor(Math.random() * AFFIRMATIONS.length)]}`,
    timestamp: new Date().toISOString()
  }]);
  const [input, setInput] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [history, loading]);

  const handleImage = (file: File) => {
    const reader = new FileReader();
    reader.onload = e => {
      const result = e.target?.result as string;
      setImagePreview(result);
      setImageBase64(result.split(',')[1]);
    };
    reader.readAsDataURL(file);
  };

  const send = async () => {
    if (!input.trim() && !imageBase64) return;
    const userMsg: ChatMessage = {
      role: 'user', text: input || 'Log this meal for me',
      image: imagePreview || undefined, timestamp: new Date().toISOString()
    };
    setHistory(h => [...h, userMsg]);
    setInput('');
    setImagePreview(null);
    setLoading(true);

    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: input, imageBase64,
          history: history.slice(-6),
          totals, targets, weeklyGoal, activities
        })
      });
      const data = await res.json();

      if (data.meal) {
        const meal: Meal = {
          id: Date.now().toString(),
          ...data.meal,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          image: imagePreview || undefined,
        };
        onMealLogged(meal);
      }
      if (data.activity) {
        const act: Activity = {
          id: Date.now().toString(),
          ...data.activity,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        onActivityLogged(act);
      }

      setHistory(h => [...h, { role: 'assistant', text: data.text, timestamp: new Date().toISOString() }]);
    } catch {
      setHistory(h => [...h, { role: 'assistant', text: "Oops! Something went wrong. Try again? 🙏", timestamp: new Date().toISOString() }]);
    }
    setImageBase64(null);
    setLoading(false);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 180px)' }}>
      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 0 8px' }}>
        {history.map((msg, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start', marginBottom: 12, animation: 'slideUp 0.3s ease' }}>
            {msg.role === 'assistant' && (
              <div style={{ width: 30, height: 30, borderRadius: '50%', background: 'linear-gradient(135deg,#FF87AB,#FFB347)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, flexShrink: 0, marginRight: 8, marginTop: 2 }}>🥗</div>
            )}
            <div style={{
              maxWidth: '78%', padding: '10px 14px',
              borderRadius: msg.role === 'user' ? '18px 18px 4px 18px' : '18px 18px 18px 4px',
              background: msg.role === 'user' ? 'linear-gradient(135deg,#FF87AB,#FFB347)' : 'white',
              color: msg.role === 'user' ? 'white' : '#1a1a2e',
              fontSize: 13, lineHeight: 1.6, fontWeight: 600,
              border: msg.role === 'assistant' ? '1px solid #f0e0f4' : 'none',
              boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
            }}>
              {msg.image && <img src={msg.image} alt="" style={{ width: '100%', borderRadius: 8, marginBottom: 8 }} />}
              <span style={{ whiteSpace: 'pre-wrap' }}>{msg.text}</span>
            </div>
          </div>
        ))}
        {loading && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <div style={{ width: 30, height: 30, borderRadius: '50%', background: 'linear-gradient(135deg,#FF87AB,#FFB347)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14 }}>🥗</div>
            <div style={{ background: 'white', border: '1px solid #f0e0f4', borderRadius: '18px 18px 18px 4px', padding: '12px 16px', display: 'flex', gap: 5 }}>
              {[0,1,2].map(i => <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: '#FF87AB', animation: `pop ${1.2 + i * 0.2}s ease infinite` }} />)}
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Image preview */}
      {imagePreview && (
        <div style={{ padding: '8px 0', display: 'flex', gap: 8, alignItems: 'center' }}>
          <img src={imagePreview} alt="" style={{ height: 56, width: 56, borderRadius: 10, objectFit: 'cover' }} />
          <button onClick={() => { setImagePreview(null); setImageBase64(null); }} style={{ background: '#FFD6E7', border: 'none', borderRadius: 8, color: '#c0395e', cursor: 'pointer', padding: '4px 10px', fontSize: 12, fontWeight: 700 }}>Remove</button>
        </div>
      )}

      {/* Input bar */}
      <div style={{ paddingTop: 12, borderTop: '1px solid #f0e0f4' }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
          <button onClick={() => fileRef.current?.click()} style={{ width: 42, height: 42, borderRadius: 12, background: '#F0E8FF', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Camera size={18} color="#A78BFA" />
          </button>
          <input ref={fileRef} type="file" accept="image/*" capture="environment" style={{ display: 'none' }} onChange={e => e.target.files?.[0] && handleImage(e.target.files[0])} />
          <textarea value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder="Type a meal, workout, or anything…"
            rows={1} style={{
              flex: 1, background: '#FFF9FB', border: '1px solid #f0e0f4',
              borderRadius: 12, padding: '10px 12px', color: '#1a1a2e', fontSize: 13,
              fontWeight: 600, outline: 'none', resize: 'none', maxHeight: 80, overflowY: 'auto', lineHeight: 1.5
            }} />
          <button onClick={send} disabled={loading} style={{
            width: 42, height: 42, borderRadius: 12, flexShrink: 0,
            background: loading ? '#f0e0f4' : 'linear-gradient(135deg,#FF87AB,#FFB347)',
            border: 'none', cursor: loading ? 'not-allowed' : 'pointer', fontSize: 16,
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }}><Send size={16} color="white" /></button>
        </div>
        <p style={{ margin: '8px 0 0', fontSize: 10, color: '#c0b0d0', textAlign: 'center', fontWeight: 600 }}>
          📸 Photo · 🍽️ Meal · 🏃 Workout · ✈️ Travel
        </p>
      </div>
    </div>
  );
}
