import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sam's Nutrition Tracker",
  description: "Daily food, activity & wellness tracker",
  manifest: "/manifest.json",
  themeColor: "#FF87AB",
  viewport: "width=device-width, initial-scale=1, maximum-scale=1",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Sam's Tracker",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="apple-touch-icon" href="/icon-192.png" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
      </head>
      <body>{children}</body>
    </html>
  );
}
