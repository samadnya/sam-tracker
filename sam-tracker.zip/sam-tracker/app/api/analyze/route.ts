import Anthropic from '@anthropic-ai/sdk';
import { NextRequest, NextResponse } from 'next/server';

const client = new Anthropic();

export async function POST(req: NextRequest) {
  const { message, imageBase64, history, totals, targets, weeklyGoal, activities } = await req.json();

  const activitySummary = activities?.length
    ? activities.map((a: any) => `${a.emoji} ${a.type} ${a.duration}min (−${a.caloriesBurned} kcal)`).join(', ')
    : 'No activities logged yet';

  const netCalories = totals.calories - (activities?.reduce((s: number, a: any) => s + a.caloriesBurned, 0) || 0);

  const system = `You are Sam's warm, enthusiastic personal nutrition coach and hype girl. Sam is a 30-year-old Indian female in NYC, 49kg, 5'2", 18% body fat. She's a busy lifestyle person who loves salmon, chicken, shrimp and Indian food. Currently recovering from a neck sprain.

Daily targets: ${targets.calories} kcal, ${targets.protein}g protein, ${targets.carbs}g carbs, ${targets.fat}g fat.
Weekly goal: "${weeklyGoal}"

Today so far: ${totals.calories} kcal eaten, ${totals.protein}g protein, ${totals.carbs}g carbs, ${totals.fat}g fat.
Activities: ${activitySummary}
Net calories (eaten minus burned): ${netCalories} kcal
Remaining calories: ${targets.calories - netCalories} kcal, ${targets.protein - totals.protein}g protein.

PERSONALITY: Be her biggest hype girl! Short, warm, punchy messages. Lots of love. Use emojis naturally. Max 3–4 sentences per response.

When Sam logs a MEAL (photo or description):
1. Identify with confidence
2. Estimate macros realistically for Indian/NYC portions
3. Give a 2-sentence hype response mentioning how it fits her day
4. End with remaining targets
5. Return this exact JSON block at the END:
<MEAL_JSON>{"name":"...","calories":0,"protein":0,"carbs":0,"fat":0,"emoji":"🍽️","mealType":"breakfast|lunch|dinner|snack","note":"short coach tip"}</MEAL_JSON>

When Sam logs an ACTIVITY (walk, dance, gym, travel, etc.):
1. Estimate calories burned based on her stats
2. Cheer her on enthusiastically
3. Return this exact JSON block at the END:
<ACTIVITY_JSON>{"type":"...","emoji":"🏃","duration":0,"caloriesBurned":0,"note":"...", "location":"optional city/place"}</ACTIVITY_JSON>

For general questions: answer warmly and helpfully, no JSON needed.
Never give the JSON block for general questions.`;

  const messages: any[] = [];

  // Include recent chat history (last 6 messages)
  const recentHistory = (history || []).slice(-6);
  for (const msg of recentHistory) {
    if (msg.role === 'user') {
      messages.push({ role: 'user', content: msg.text });
    } else {
      messages.push({ role: 'assistant', content: msg.text });
    }
  }

  // Current message
  const content: any[] = [];
  if (imageBase64) {
    content.push({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: imageBase64 } });
  }
  content.push({ type: 'text', text: message || 'Analyze this and log it for me.' });
  messages.push({ role: 'user', content });

  const response = await client.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 600,
    system,
    messages,
  });

  const fullText = response.content.map((b: any) => b.text || '').join('');

  // Extract JSON blocks
  const mealMatch = fullText.match(/<MEAL_JSON>([\s\S]*?)<\/MEAL_JSON>/);
  const activityMatch = fullText.match(/<ACTIVITY_JSON>([\s\S]*?)<\/ACTIVITY_JSON>/);
  const displayText = fullText
    .replace(/<MEAL_JSON>[\s\S]*?<\/MEAL_JSON>/, '')
    .replace(/<ACTIVITY_JSON>[\s\S]*?<\/ACTIVITY_JSON>/, '')
    .trim();

  let mealData = null, activityData = null;
  if (mealMatch) { try { mealData = JSON.parse(mealMatch[1]); } catch {} }
  if (activityMatch) { try { activityData = JSON.parse(activityMatch[1]); } catch {} }

  return NextResponse.json({ text: displayText, meal: mealData, activity: activityData });
}
