'use client';
import { useState, useEffect, useCallback } from 'react';
import { Meal, Activity, DayLog, UserProfile } from '@/lib/types';
import { getProfile, saveProfile, getDayLog, saveDayLog, getLast7Days } from '@/lib/storage';
import GoalBanner from '@/components/GoalBanner';
import ActivityLogger from '@/components/ActivityLogger';
import ProgressCharts from '@/components/ProgressCharts';
import CoachChat from '@/components/CoachChat';
import { Trash2, Droplets, Scale } from 'lucide-react';

const MOODS = ['😴','😐','🙂','😊','🔥'];

const AFFIRMATIONS: Record<string, string[]> = {
  excellent: ["Absolutely crushing it today! 🔥", "This is what dedication looks like! ⭐", "Your body is glowing from the inside 💕", "Perfect day — you earned it! 🌟"],
  good: ["Really solid choices today! 👏", "Consistency > perfection — you've got this! ✨", "Strong work! Keep that momentum 💪", "You're doing amazing! 🎯"],
  okay: ["Still in the game! Adjust dinner and you're golden 🎯", "Not every day is perfect — next meal resets it 💫", "Mid-day reset! You have time to nail the rest 🌸"],
  off: ["Life happens! One meal never defines your journey 🤍", "Tomorrow is a fresh slate ✨", "Even off days are data — learning and moving forward 🌱"],
};

function getMotivation(pct: number) {
  if (pct >= 88 && pct <= 105) return { msgs: AFFIRMATIONS.excellent, color: '#00D4A0', emoji: '🔥', label: 'Crushing it!' };
  if (pct >= 65) return { msgs: AFFIRMATIONS.good, color: '#FFB347', emoji: '⭐', label: 'Doing great!' };
  if (pct >= 40) return { msgs: AFFIRMATIONS.okay, color: '#FF87AB', emoji: '💫', label: 'On track' };
  return { msgs: AFFIRMATIONS.off, color: '#A78BFA', emoji: '🤍', label: 'Keep going' };
}

export default function Home() {
  const [tab, setTab] = useState<'today'|'coach'|'progress'|'plan'>('today');
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [dayLog, setDayLog] = useState<DayLog | null>(null);
  const [last7, setLast7] = useState<DayLog[]>([]);
  const [affirmation, setAffirmation] = useState('');

  useEffect(() => {
    const p = getProfile();
    const d = getDayLog();
    const l7 = getLast7Days();
    setProfile(p);
    setDayLog(d);
    setLast7(l7);
  }, []);

  const save = useCallback((log: DayLog) => {
    setDayLog(log);
    saveDayLog(log);
    setLast7(getLast7Days());
  }, []);

  const saveProf = useCallback((p: UserProfile) => {
    setProfile(p);
    saveProfile(p);
  }, []);

  useEffect(() => {
    if (!profile || !dayLog) return;
    const t = totals();
    const pct = (t.calories / profile.targets.calories) * 100;
    const m = getMotivation(pct);
    setAffirmation(m.msgs[Math.floor(Math.random() * m.msgs.length)]);
  }, [profile, dayLog]);

  if (!profile || !dayLog) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', flexDirection: 'column', gap: 12 }}>
      <div style={{ fontSize: 36 }}>🌸</div>
      <div style={{ fontSize: 14, fontWeight: 700, color: '#8a7a9a' }}>Loading your tracker…</div>
    </div>
  );

  const totals = () => dayLog.meals.reduce(
    (acc, m) => ({ calories: acc.calories + m.calories, protein: acc.protein + m.protein, carbs: acc.carbs + m.carbs, fat: acc.fat + m.fat }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );

  const totalBurned = dayLog.activities.reduce((s, a) => s + a.caloriesBurned, 0);
  const t = totals();
  const netCals = t.calories - totalBurned;
  const calPct = (netCals / profile.targets.calories) * 100;
  const motiv = getMotivation(calPct);
  const remaining = { cal: Math.max(0, profile.targets.calories - netCals), protein: Math.max(0, profile.targets.protein - t.protein) };

  const addMeal = (m: Meal) => save({ ...dayLog, meals: [...dayLog.meals, m] });
  const delMeal = (id: string) => save({ ...dayLog, meals: dayLog.meals.filter(m => m.id !== id) });
  const addActivity = (a: Activity) => save({ ...dayLog, activities: [...dayLog.activities, a] });
  const delActivity = (id: string) => save({ ...dayLog, activities: dayLog.activities.filter(a => a.id !== id) });
  const setWater = (n: number) => save({ ...dayLog, water: n });
  const setWeight = (w: number) => save({ ...dayLog, weight: w });
  const setMood = (m: string) => save({ ...dayLog, mood: m });

  const pBar = (val: number, max: number, color: string) => (
    <div style={{ background: '#f0e8f8', borderRadius: 99, height: 6, overflow: 'hidden', marginTop: 5 }}>
      <div style={{ height: '100%', width: `${Math.min(val / max * 100, 100)}%`, background: color, borderRadius: 99, transition: 'width 1s ease' }} />
    </div>
  );

  const TABS = [
    { key: 'today', label: '📊 Today' },
    { key: 'coach', label: '💬 Coach' },
    { key: 'progress', label: '📈 Progress' },
    { key: 'plan', label: '📅 Plan' },
  ] as const;

  return (
    <div style={{ minHeight: '100vh', paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ padding: '20px 16px 0', position: 'sticky', top: 0, background: '#FFF9FB', zIndex: 20, borderBottom: '1px solid #f5eef8' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <div>
            <h1 style={{ margin: 0, fontFamily: 'Syne, sans-serif', fontSize: 22, fontWeight: 800, letterSpacing: '-0.02em', color: '#1a1a2e' }}>
              Hey Sam! 👋
            </h1>
            <p style={{ margin: '2px 0 0', fontSize: 11, color: '#8a7a9a', fontWeight: 600 }}>
              {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
            </p>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 22 }}>{motiv.emoji}</div>
            <div style={{ fontSize: 10, color: motiv.color, fontWeight: 800, marginTop: 1 }}>{motiv.label}</div>
          </div>
        </div>
        {/* Tabs */}
        <div style={{ display: 'flex', gap: 4, background: '#f5eef8', borderRadius: 12, padding: 4, marginBottom: -1 }}>
          {TABS.map(t => (
            <button key={t.key} onClick={() => setTab(t.key)} style={{
              flex: 1, padding: '7px 0', borderRadius: 9, border: 'none', cursor: 'pointer',
              fontSize: 11, fontWeight: 800, fontFamily: 'Nunito, sans-serif',
              background: tab === t.key ? 'white' : 'transparent',
              color: tab === t.key ? '#1a1a2e' : '#8a7a9a',
              boxShadow: tab === t.key ? '0 1px 4px rgba(0,0,0,0.08)' : 'none',
              transition: 'all 0.2s'
            }}>{t.label}</button>
          ))}
        </div>
      </div>

      <div style={{ padding: '16px 16px 0' }}>

        {/* ═══ TODAY ═══ */}
        {tab === 'today' && (
          <div className="slide-up">
            <GoalBanner goal={profile.weeklyGoal} onSave={g => saveProf({ ...profile, weeklyGoal: g })} />

            {/* Calorie hero */}
            <div className="gradient-hero card mb-3">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontSize: 38, fontWeight: 900, fontFamily: 'Syne, sans-serif', color: '#3a2a5e', lineHeight: 1 }}>{netCals}</div>
                  <div style={{ fontSize: 12, color: '#7a6a9e', fontWeight: 600, marginTop: 2 }}>net kcal · {remaining.cal} remaining</div>
                  {totalBurned > 0 && <div style={{ fontSize: 11, color: '#00D4A0', fontWeight: 700, marginTop: 2 }}>🔥 {totalBurned} burned = {t.calories} eaten − {totalBurned}</div>}
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: 11, color: '#d4567a', fontWeight: 700 }}>{remaining.protein}g protein left</div>
                  <div style={{ fontSize: 10, color: '#8a7a9a', marginTop: 2 }}>of {profile.targets.protein}g goal</div>
                </div>
              </div>
              <div style={{ background: 'rgba(255,255,255,0.4)', borderRadius: 99, height: 7, overflow: 'hidden', margin: '10px 0' }}>
                <div style={{ height: '100%', width: `${Math.min(calPct, 100)}%`, background: 'linear-gradient(90deg,#FF87AB,#FFB347)', borderRadius: 99, transition: 'width 1.2s ease' }} />
              </div>
              <div style={{ fontSize: 12, color: '#d4567a', fontWeight: 700, fontStyle: 'italic', lineHeight: 1.4 }}>"{affirmation}"</div>
            </div>

            {/* Macro grid */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 12 }}>
              {[
                { label: '🥩 Protein', val: t.protein, max: profile.targets.protein, color: '#FF87AB', unit: 'g' },
                { label: '🍚 Carbs', val: t.carbs, max: profile.targets.carbs, color: '#FFB347', unit: 'g' },
                { label: '🥑 Fat', val: t.fat, max: profile.targets.fat, color: '#A78BFA', unit: 'g' },
                { label: '💧 Water', val: dayLog.water, max: 8, color: '#60C8F0', unit: ' glasses' },
              ].map(m => (
                <div key={m.label} className="card" style={{ padding: '12px 14px' }}>
                  <div style={{ fontSize: 11, fontWeight: 800, color: '#8a7a9a', marginBottom: 4 }}>{m.label}</div>
                  <div style={{ fontSize: 18, fontWeight: 900, color: '#1a1a2e' }}>{m.val}<span style={{ fontSize: 10, color: '#8a7a9a', marginLeft: 2 }}>/ {m.max}{m.unit}</span></div>
                  {pBar(m.val, m.max, m.color)}
                </div>
              ))}
            </div>

            {/* Water & weight */}
            <div className="card mb-3">
              <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 11, fontWeight: 800, color: '#8a7a9a', marginBottom: 6 }}>💧 Water glasses</div>
                  <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                    {[1,2,3,4,5,6,7,8].map(n => (
                      <button key={n} onClick={() => setWater(dayLog.water === n ? n-1 : n)} style={{
                        width: 28, height: 28, borderRadius: 8, border: '1px solid #f0e0f4',
                        background: n <= dayLog.water ? '#D5E8FF' : 'white',
                        cursor: 'pointer', fontSize: 14, display: 'flex', alignItems: 'center', justifyContent: 'center'
                      }}>{n <= dayLog.water ? '💧' : '🫧'}</button>
                    ))}
                  </div>
                </div>
                <div style={{ width: 1, background: '#f0e0f4', height: 48, flexShrink: 0 }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 11, fontWeight: 800, color: '#8a7a9a', marginBottom: 6 }}>⚖️ Weight (kg)</div>
                  <input type="number" step="0.1" min="30" max="120"
                    defaultValue={dayLog.weight}
                    onBlur={e => e.target.value && setWeight(parseFloat(e.target.value))}
                    placeholder="e.g. 49.0"
                    style={{ width: '100%', border: '1px solid #f0e0f4', borderRadius: 10, padding: '6px 10px', fontSize: 13, fontWeight: 700, outline: 'none', background: '#FFF9FB' }}
                  />
                </div>
              </div>
            </div>

            {/* Mood */}
            <div className="card mb-3">
              <div style={{ fontSize: 11, fontWeight: 800, color: '#8a7a9a', marginBottom: 8 }}>How are you feeling? ✨</div>
              <div style={{ display: 'flex', gap: 8 }}>
                {MOODS.map(m => (
                  <button key={m} onClick={() => setMood(m)} style={{
                    flex: 1, padding: '8px 0', borderRadius: 10, border: dayLog.mood === m ? '2px solid #FF87AB' : '1px solid #f0e0f4',
                    background: dayLog.mood === m ? '#FFD6E7' : 'white', cursor: 'pointer', fontSize: 18
                  }}>{m}</button>
                ))}
              </div>
            </div>

            {/* Activity */}
            <ActivityLogger activities={dayLog.activities} onAdd={addActivity} onDelete={delActivity} />

            {/* Meals */}
            <div style={{ fontSize: 11, fontWeight: 800, color: '#8a7a9a', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 8 }}>
              Meals logged · {dayLog.meals.length}
            </div>
            {dayLog.meals.length === 0 && (
              <div style={{ textAlign: 'center', padding: '24px', color: '#c0b0d0', fontSize: 13, fontWeight: 600 }}>
                No meals logged yet — go to Coach tab to snap or type! 📸
              </div>
            )}
            {dayLog.meals.map(m => (
              <div key={m.id} className="card mb-2" style={{ display: 'flex', gap: 10, alignItems: 'flex-start', padding: '12px' }}>
                {m.image
                  ? <img src={m.image} alt="" style={{ width: 44, height: 44, borderRadius: 10, objectFit: 'cover', flexShrink: 0 }} />
                  : <div style={{ width: 44, height: 44, borderRadius: 10, background: '#FFF0F5', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>{m.emoji}</div>
                }
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: '#1a1a2e', marginBottom: 2 }}>{m.name}</div>
                  <div style={{ fontSize: 11, color: '#8a7a9a', marginBottom: m.note ? 4 : 0 }}>
                    {m.time} · {m.calories} kcal · {m.protein}g P · {m.carbs}g C · {m.fat}g F
                  </div>
                  {m.note && <div style={{ fontSize: 11, color: '#FF87AB', fontWeight: 700, fontStyle: 'italic' }}>{m.note}</div>}
                </div>
                <button onClick={() => delMeal(m.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#ddd', padding: '0 2px' }}><Trash2 size={14} /></button>
              </div>
            ))}

            <button onClick={() => setTab('coach')} style={{
              width: '100%', padding: '14px', borderRadius: 14, border: 'none',
              background: 'linear-gradient(135deg,#FF87AB,#FFB347)',
              color: 'white', fontWeight: 800, fontSize: 14, cursor: 'pointer',
              boxShadow: '0 4px 16px rgba(255,135,171,0.3)', marginTop: 8
            }}>📸 Log a meal or workout →</button>
          </div>
        )}

        {/* ═══ COACH ═══ */}
        {tab === 'coach' && (
          <div className="slide-up">
            <CoachChat
              totals={t} targets={profile.targets} weeklyGoal={profile.weeklyGoal}
              activities={dayLog.activities} onMealLogged={addMeal} onActivityLogged={addActivity}
            />
          </div>
        )}

        {/* ═══ PROGRESS ═══ */}
        {tab === 'progress' && (
          <div className="slide-up">
            {/* Weekly stats */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 12 }}>
              {[
                { label: 'Day streak 🔥', val: profile.currentStreak, unit: 'days' },
                { label: 'Avg protein', val: Math.round(last7.reduce((s,d) => s + d.meals.reduce((ss,m) => ss + m.protein, 0), 0) / 7), unit: 'g/day' },
                { label: 'Avg calories', val: Math.round(last7.reduce((s,d) => s + d.meals.reduce((ss,m) => ss + m.calories, 0), 0) / 7), unit: 'kcal/day' },
                { label: 'Total burned', val: last7.reduce((s,d) => s + d.activities.reduce((ss,a) => ss + a.caloriesBurned, 0), 0), unit: 'kcal' },
              ].map(s => (
                <div key={s.label} className="card" style={{ textAlign: 'center', padding: '14px' }}>
                  <div style={{ fontSize: 22, fontWeight: 900, color: '#1a1a2e', fontFamily: 'Syne, sans-serif' }}>{s.val || 0}</div>
                  <div style={{ fontSize: 10, color: '#8a7a9a', fontWeight: 700, marginTop: 2 }}>{s.label}</div>
                  <div style={{ fontSize: 10, color: '#A78BFA', fontWeight: 600 }}>{s.unit}</div>
                </div>
              ))}
            </div>
            <ProgressCharts logs={last7} targets={profile.targets} />
          </div>
        )}

        {/* ═══ PLAN ═══ */}
        {tab === 'plan' && (
          <div className="slide-up">
            <div style={{ marginBottom: 16 }}>
              <h2 style={{ fontSize: 18, fontWeight: 800, fontFamily: 'Syne, sans-serif', margin: '0 0 4px', color: '#1a1a2e' }}>Your 5-Day Plan 🌸</h2>
              <p style={{ fontSize: 12, color: '#8a7a9a', margin: 0, fontWeight: 600 }}>Neck sprain recovery · Fat loss focus · 1,400 kcal</p>
            </div>

            {[
              { day: 'Thu', col: '#FF87AB', bg: '#FFD6E7', meals: ['Mush Overnight Oats', 'Cilantro Lime Chicken Salad', 'Salmon + Broccoli', 'Protein Shake + Cottage Cheese'], workout: '30 min incline walk · Legs · Abs circuit' },
              { day: 'Fri', col: '#A78BFA', bg: '#E8D5FF', meals: ['Egg White Omelette + Spinach', 'Shrimp Stir Fry + Zucchini', 'Chicken Tenders + Asparagus', 'Protein Shake'], workout: '20 min dance cardio 💃 · Abs' },
              { day: 'Sat', col: '#00D4A0', bg: '#C8F0E0', meals: ['Mush Overnight Oats', 'Salmon Salad + Arugula', 'Shrimp + Sweet Potato + Greens', 'Protein Shake'], workout: 'Lower body strength · 20 min bike/elliptical' },
              { day: 'Sun', col: '#FFB347', bg: '#FFE8C2', meals: ['Eggs + Smoked Salmon', 'Chipotle bowl (no rice)', 'Baked Salmon + Broccoli + Fage'], workout: 'Active recovery · Long NYC walk 🌆' },
              { day: 'Mon', col: '#60C8F0', bg: '#D5E8FF', meals: ['Mush Overnight Oats', 'Chicken + Big Green Salad', 'Shrimp + Sautéed Spinach', 'Protein Shake + Cottage Cheese'], workout: 'Legs + Abs · 25 min incline walk' },
            ].map((d, i) => (
              <div key={i} className="card mb-3" style={{ borderLeft: `3px solid ${d.col}`, padding: '14px 14px 14px 12px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                  <span style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 16, color: d.col }}>{d.day}</span>
                  <span style={{ fontSize: 10, color: '#8a7a9a', background: '#f5eef8', padding: '3px 8px', borderRadius: 99, fontWeight: 700 }}>~1,400 kcal</span>
                </div>
                <div style={{ marginBottom: 8 }}>
                  {d.meals.map((m, j) => <p key={j} style={{ margin: '0 0 3px', fontSize: 12, color: '#5a4a7e', fontWeight: 600 }}>· {m}</p>)}
                </div>
                <div style={{ background: d.bg, borderRadius: 8, padding: '7px 10px', fontSize: 12, fontWeight: 700, color: '#3a2a5e' }}>
                  💪 {d.workout}
                </div>
              </div>
            ))}

            {/* Sam's rules */}
            <div className="card" style={{ marginTop: 4 }}>
              <div style={{ fontSize: 12, fontWeight: 800, color: '#8a7a9a', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 10 }}>⚡ Sam's rules this week</div>
              {[
                ['🥩', 'Protein first at every meal', '125g+ daily protects your muscle'],
                ['☕', 'Cold brew = black or light cream', 'Saves 150–200 kcal for real food'],
                ['🚶', 'Walk everywhere in Manhattan', 'NYC walking is elite-level cardio'],
                ['🩺', 'Neck first — no rushing back', 'Legs + core carry fat loss this week'],
                ['💧', '8 glasses of water daily', 'Recovery, skin glow, appetite control'],
                ['😴', 'Sleep 7–8 hours', 'Sleep is when fat loss actually happens'],
              ].map(([icon, title, sub]) => (
                <div key={title} style={{ display: 'flex', gap: 10, padding: '8px 0', borderBottom: '1px solid #f5eef8' }}>
                  <span style={{ fontSize: 16 }}>{icon}</span>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: '#1a1a2e' }}>{title}</div>
                    <div style={{ fontSize: 11, color: '#8a7a9a' }}>{sub}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
